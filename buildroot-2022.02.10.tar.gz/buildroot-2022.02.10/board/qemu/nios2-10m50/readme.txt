Run the emulation with:

  qemu-system-nios2 -kernel output/images/vmlinux -nographic # qemu_nios2_10m50_defconfig

The login prompt will appear in the terminal that started Qemu.
